package ar.edu.centro8.Proyecto01;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Proyecto01Application {

	public static void main(String[] args) {
		SpringApplication.run(Proyecto01Application.class, args);
	}

}
